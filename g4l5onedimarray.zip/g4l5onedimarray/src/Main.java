public class Main {
    public static void main(String[] args) {


         int  tab[] = new int[100] ;

        for (int i = 0; i <=100 ; i++){
            ;
        }

            System.out.println();

    }
}